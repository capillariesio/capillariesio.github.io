import os.path
import sys
import re,time
import csv
import json

all_countries = {}
all_sectors = {}
all_partners = {}
all_projects = {}

def isoToInt(iso):
    p = iso.split("-")

    if len(p) < 3 or len(p[0]) < 4  or len(p[1]) < 2 or len(p[0]) < 2:
        return 0
    return int(p[0])*10000 + int(p[1])*100 + int(p[2])

def process_html(project_id, partner_id, amt, start, end, w):
    with open('projects_html/' + project_id + ".html", "r", encoding="utf8") as f:
        content = f.read()
        
        countries_obj = {}
        total_percent = 0
        re_countries = re.compile(r'<span>[•]*([a-zA-Z/(), ô\'\-]+) \(([0-9.]+)%\)</span><br>')
        for m in re_countries.finditer(content):
            country = m.group(1).strip()
            if not country in all_countries:
                print(f"bad country {country} in {project_id}")
                sys.exit(1)

            country_code = all_countries[country]
            percent = float(m.group(2))
            total_percent += percent
            countries_obj[country_code] = round(percent*amt/100.0,2)
        if total_percent < 99.999 or total_percent > 100.001:
            print(f"bad country total percent in {project_id}: {total_percent}")
            sys.exit(1)
        
        sectors_obj = {}
        total_percent = 0.0
        re_sectors = re.compile(r'<span[^>]*>[•]*([a-zA-Z19/() :\-–,;&\'\+]+) \(([0-9]+)\) \(([0-9.]+)%\)</span><br>')
        for m in re_sectors.finditer(content):
            sector_name = m.group(1).strip()
            sector_id = m.group(2).strip()
            all_sectors[sector_id] = sector_name
            percent = float(m.group(3))
            total_percent += percent
            sectors_obj[sector_id] = round(percent*amt/100.0,2)
        if total_percent < 99.999 or total_percent > 100.001:
            print(f"bad sector total percent in {project_id}: {total_percent}")
            sys.exit(1)

        w.writerow([project_id,partner_id,amt,start,end,f"{json.dumps(countries_obj, ensure_ascii=False)}", f"{json.dumps(sectors_obj, ensure_ascii=False)}"])

with open('countries.csv', encoding="utf8") as csvfile:
    r = csv.reader(csvfile, delimiter=',', quotechar='"')
    next(r, None) # Skip header
    for row in r:
        all_countries[row[1]] = row[0]

with open('harvested_projects.csv', encoding="utf8") as csvfile:
    r = csv.reader(csvfile, delimiter=',', quotechar='"')
    next(r, None) # Skip header
    with open("harvested_project_financials_bigtest.csv", "w+", encoding="utf8",newline='') as f_project_budget:
        w_project_budget = csv.writer(f_project_budget, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        w_project_budget.writerow(['project_id','partner_id','amt','start_date','end_date','country_amt_json','sector_amt_json'])
        for row in r:
            project_url = row[0]
            project_url_parts = project_url.split("/")
            project_id = project_url_parts[len(project_url_parts)-1]
            partner_url = row[3]
            partner_url_parts = partner_url.split("/")
            partner_id = partner_url_parts[len(partner_url_parts)-1]
            start = isoToInt(row[6])
            end = isoToInt(row[7])
            if len(row[2]) == 0:
                print(f"No amount: {project_id}")
            elif start == 0:
                print(f"No start: {project_id}")
            elif end == 0:
                print(f"No end: {project_id}")
            else:
                if start > end:
                    # Start > end (20140331 > 20140330): m013882001, flipping
                    # Start > end (20150326 > 20141021): d001628003, flipping
                    print(f"Start > end ({start} > {end}): {project_id}, flipping")
                    t = end
                    end = start
                    start = t
                all_projects[project_id] = row[1].strip()
                all_partners[partner_id] = row[4].strip()
                process_html(project_id, partner_id,float(row[2].replace("$","",1).replace(",","")), start, end, w_project_budget)

sorted_sector_ids = list(all_sectors.keys())
sorted_sector_ids.sort()
with open('sectors.csv', "w+", encoding="utf8",newline='') as fcsv:
    w = csv.writer(fcsv, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    w.writerow(['sector_id','sector_name'])
    for sector_id in sorted_sector_ids:
        w.writerow([sector_id,all_sectors[sector_id]])

sorted_project_ids = list(all_projects.keys())
sorted_project_ids.sort()
with open('projects.csv', "w+", encoding="utf8",newline='') as fcsv:
    w = csv.writer(fcsv, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    w.writerow(['project_id','project_name'])
    for project_id in sorted_project_ids:
        w.writerow([project_id,all_projects[project_id]])

sorted_partner_ids = list(all_partners.keys())
sorted_partner_ids.sort()
with open('partners.csv', "w+", encoding="utf8",newline='') as fcsv:
    w = csv.writer(fcsv, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    w.writerow(['partner_id','partner_name'])
    for partner_id in sorted_partner_ids:
        w.writerow([partner_id,all_partners[partner_id]])
