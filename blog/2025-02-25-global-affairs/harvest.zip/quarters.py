for y in range(1996,2048):
    for q in range(1,5):
        print(f"{y}-Q{q}")