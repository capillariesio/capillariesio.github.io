import os.path
import re,time
from playwright.sync_api import sync_playwright
import csv

def sanitize_href(href):
   return href.replace("/","-").replace("#","hash")

def scrape_url(url, project_id):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        while True:
            try:
                page.goto(url)
                break
            except Exception as e:
                print(e)
        page.wait_for_selector('.btn')
        # time.sleep(1)
        content = page.content()
        # hrefs = re.findall(r'href="([a-z0-9_#\/]+)"', content)
        # for href in hrefs:
        #     content = content.replace('href="'+href+'"', 'href="'+sanitize_href(href)+'.html"')
        # content.replace("/global.css","global.css").replace("/build/","build/")
        # content = content.replace("/global.css","global.css").replace("/build/","build/")
        # fname = sanitize_href(url.replace(root_url,"")) + '.html'

        with open('projects_html\\' + project_id + ".html", "w+", encoding="utf-8") as f:
            # Remove all script references
            f.write(content)
        
        browser.close()

    print(url)

with open('all2.csv', encoding="utf8") as csvfile:
    r = csv.reader(csvfile, delimiter=',', quotechar='"')
    for row in r:
        url = row[0]
        url_parts = url.split("/")
        project_id = url_parts[len(url_parts)-1]
        if not os.path.isfile("projects_html\\"+project_id+".html"):
            scrape_url(url, project_id)
        else:
            print("Already here:" + project_id)
